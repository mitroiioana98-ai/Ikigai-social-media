-- IKIGAI AI Social Manager: initial schema
-- Apply this migration in Supabase SQL Editor or with Supabase CLI.
create extension if not exists pgcrypto;

do $$ begin
  create type public.social_platform as enum ('instagram','tiktok','facebook','linkedin','youtube');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.content_format as enum ('reel','short','carousel','single_image','story','text_post','long_video');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.approval_status as enum ('draft','pending','approved','rejected','scheduled','published');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.research_status as enum ('new','reviewed','used','archived');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  slug text not null unique,
  tagline text,
  description text,
  primary_language text not null default 'English',
  timezone text not null default 'Europe/Bucharest',
  brand_voice text[] not null default array['intelligent','thoughtful','elegant','modern','warm','inspiring'],
  color_palette jsonb not null default '["#F5F0E8","#E9DFD1","#C9B8A3","#A58E78","#6F5B49","#C6A878"]'::jsonb,
  approval_required boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.platform_accounts (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  platform public.social_platform not null,
  account_name text,
  external_account_id text,
  connection_status text not null default 'not_connected' check (connection_status in ('not_connected','connected','expired','error')),
  provider text,
  connected_at timestamptz,
  created_at timestamptz not null default now(),
  unique (brand_id, platform, external_account_id)
);

create table if not exists public.content_pillars (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  name text not null,
  description text,
  objective text,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique (brand_id, name)
);

create table if not exists public.research_items (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  title text not null,
  source_url text,
  source_name text,
  summary text,
  content_angle text,
  platform public.social_platform,
  status public.research_status not null default 'new',
  published_at timestamptz,
  researched_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.content_ideas (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  pillar_id uuid references public.content_pillars(id) on delete set null,
  research_item_id uuid references public.research_items(id) on delete set null,
  title text not null,
  hook text,
  angle text,
  objective text,
  target_audience text,
  suggested_formats public.content_format[] not null default '{}',
  status text not null default 'idea' check (status in ('idea','selected','developed','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.content_posts (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  idea_id uuid references public.content_ideas(id) on delete set null,
  pillar_id uuid references public.content_pillars(id) on delete set null,
  title text not null,
  caption text,
  hook text,
  script text,
  hashtags text[] not null default '{}',
  platform public.social_platform not null,
  format public.content_format not null,
  approval_status public.approval_status not null default 'draft',
  scheduled_at timestamptz,
  published_at timestamptz,
  external_post_id text,
  media_storage_path text,
  media_url text,
  created_by uuid references auth.users(id) on delete set null,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint approved_fields_consistent check (
    (approval_status not in ('approved','scheduled','published')) or (approved_by is not null and approved_at is not null)
  )
);

create table if not exists public.post_revisions (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.content_posts(id) on delete cascade,
  version integer not null,
  snapshot jsonb not null,
  change_note text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(post_id, version)
);

create table if not exists public.approvals (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.content_posts(id) on delete cascade,
  requested_by uuid references auth.users(id) on delete set null,
  reviewer_id uuid references auth.users(id) on delete set null,
  decision text not null default 'pending' check (decision in ('pending','approved','rejected','changes_requested')),
  feedback text,
  decided_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.publishing_jobs (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.content_posts(id) on delete cascade,
  platform public.social_platform not null,
  scheduled_for timestamptz not null,
  status text not null default 'queued' check (status in ('queued','processing','published','failed','cancelled')),
  provider_job_id text,
  attempts integer not null default 0,
  last_error text,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  post_id uuid references public.content_posts(id) on delete set null,
  file_name text not null,
  storage_path text not null,
  mime_type text,
  file_size_bytes bigint,
  alt_text text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.analytics_snapshots (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  post_id uuid references public.content_posts(id) on delete cascade,
  platform public.social_platform not null,
  captured_at timestamptz not null default now(),
  impressions bigint,
  reach bigint,
  views bigint,
  likes bigint,
  comments bigint,
  shares bigint,
  saves bigint,
  clicks bigint,
  followers_gained integer,
  engagement_rate numeric(8,5),
  raw_metrics jsonb not null default '{}'::jsonb
);

create table if not exists public.ai_runs (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands(id) on delete cascade,
  agent_name text not null,
  task_type text not null,
  status text not null default 'queued' check (status in ('queued','running','succeeded','failed','cancelled')),
  model text,
  input_summary text,
  output_summary text,
  error_message text,
  tokens_input integer,
  tokens_output integer,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists idx_brands_owner on public.brands(owner_id);
create index if not exists idx_posts_brand_created on public.content_posts(brand_id, created_at desc);
create index if not exists idx_posts_approval on public.content_posts(brand_id, approval_status);
create index if not exists idx_posts_schedule on public.content_posts(scheduled_at) where scheduled_at is not null;
create index if not exists idx_research_brand_status on public.research_items(brand_id, status);
create index if not exists idx_analytics_brand_captured on public.analytics_snapshots(brand_id, captured_at desc);
create index if not exists idx_ai_runs_brand_created on public.ai_runs(brand_id, created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;

do $$ declare t text; begin
  foreach t in array array['profiles','brands','content_ideas','content_posts','publishing_jobs'] loop
    execute format('drop trigger if exists set_%I_updated_at on public.%I', t, t);
    execute format('create trigger set_%I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name) values (new.id, coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1))) on conflict (id) do nothing;
  insert into public.brands (owner_id, name, slug, tagline, description)
  values (new.id, 'IKIGAI PROJECT', 'ikigai-' || replace(new.id::text, '-', ''), 'Discover what makes your life meaningful.', 'A thoughtful space for self-discovery, career exploration and meaningful work.')
  on conflict (slug) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.brands enable row level security;
alter table public.platform_accounts enable row level security;
alter table public.content_pillars enable row level security;
alter table public.research_items enable row level security;
alter table public.content_ideas enable row level security;
alter table public.content_posts enable row level security;
alter table public.post_revisions enable row level security;
alter table public.approvals enable row level security;
alter table public.publishing_jobs enable row level security;
alter table public.media_assets enable row level security;
alter table public.analytics_snapshots enable row level security;
alter table public.ai_runs enable row level security;

create policy "Users can read own profile" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "Users can update own profile" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "Owners manage their brands" on public.brands for all to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));

-- Child records are visible and writable only when their brand belongs to the signed-in user.
do $$ declare t text; begin
  foreach t in array array['platform_accounts','content_pillars','research_items','content_ideas','content_posts','media_assets','analytics_snapshots','ai_runs'] loop
    execute format('create policy "Brand owners manage %I" on public.%I for all to authenticated using (exists (select 1 from public.brands b where b.id = brand_id and b.owner_id = (select auth.uid()))) with check (exists (select 1 from public.brands b where b.id = brand_id and b.owner_id = (select auth.uid())))', t, t);
  end loop;
end $$;

create policy "Brand owners manage post revisions" on public.post_revisions for all to authenticated
using (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())))
with check (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())));
create policy "Brand owners manage approvals" on public.approvals for all to authenticated
using (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())))
with check (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())));
create policy "Brand owners manage publishing jobs" on public.publishing_jobs for all to authenticated
using (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())))
with check (exists (select 1 from public.content_posts p join public.brands b on b.id = p.brand_id where p.id = post_id and b.owner_id = (select auth.uid())));

-- Brand starter data is inserted by the auth.users trigger in handle_new_user().
-- Add the initial IKIGAI content pillars for each newly-created brand.
create or replace function public.seed_ikigai_pillars()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.name = 'IKIGAI PROJECT' then
    insert into public.content_pillars (brand_id, name, description, objective, sort_order) values
      (new.id, 'Self-discovery', 'Understand strengths, values, interests and identity.', 'Build self-awareness', 1),
      (new.id, 'Ikigai & meaning', 'Explore purpose, meaning and the Japanese concept of ikigai with nuance.', 'Educate and inspire', 2),
      (new.id, 'Career exploration', 'Help people navigate career questions, transitions and possibilities.', 'Support career clarity', 3),
      (new.id, 'Personal growth', 'Share thoughtful ideas about learning, resilience and development.', 'Encourage growth', 4),
      (new.id, 'Practical reflection', 'Offer prompts, exercises and actionable reflection tools.', 'Drive meaningful engagement', 5)
    on conflict (brand_id, name) do nothing;
  end if;
  return new;
end; $$;
drop trigger if exists on_ikigai_brand_created on public.brands;
create trigger on_ikigai_brand_created after insert on public.brands for each row execute procedure public.seed_ikigai_pillars();
