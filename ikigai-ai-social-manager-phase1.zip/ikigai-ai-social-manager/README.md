# IKIGAI AI Social Manager

A Next.js + Supabase foundation for an approval-first AI social media workspace for IKIGAI PROJECT.

## Phase 1 scope

- Next.js App Router dashboard shell, responsive layout and login screen
- Supabase SSR authentication helpers and protected dashboard route
- PostgreSQL schema for brand settings, channels, research, ideas, content, approvals, publishing jobs, media, analytics and AI runs
- Row Level Security policies scoped to the authenticated brand owner
- New-user trigger that creates an IKIGAI PROJECT brand and its five content pillars
- Approval-first default: content starts as `draft`; the brand has `approval_required = true`

## Requirements

- Node.js 20.9+
- A Supabase project
- npm

## Run locally

```bash
npm install
cp .env.example .env.local
# Add your Supabase URL and publishable/anon key to .env.local
npm run dev
```

Open http://localhost:3000.

## Configure Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/migrations/0001_initial_schema.sql`.
3. In **Authentication -> Providers**, enable Email.
4. In **Authentication -> URL Configuration**, set the local site URL to `http://localhost:3000` and add `http://localhost:3000/auth/callback` to the redirect URLs.
5. Create the first user in **Authentication -> Users**. The database trigger creates the profile, IKIGAI PROJECT brand and five content pillars.
6. Copy the Project URL and publishable/anon key into `.env.local`.

For production, add the same public Supabase settings to Vercel environment variables and update Supabase's Site URL and redirect allow-list to the deployed domain.

## Security notes

- Never commit `.env.local` or service-role keys.
- Only public Supabase URL + publishable/anon key belong in `NEXT_PUBLIC_` variables.
- Service-role credentials, AI provider keys and social platform tokens must remain server-side secrets.
- RLS is enabled for every application table. Policies scope records through the authenticated user's owned brand.
- Social publishing is intentionally not implemented in Phase 1. Later publishing jobs must verify an approved post on the server immediately before dispatch.

## Current state

The dashboard has a preview mode with illustrative sample content until Supabase environment variables are configured. Live data is loaded from `content_posts` once Supabase is connected.
