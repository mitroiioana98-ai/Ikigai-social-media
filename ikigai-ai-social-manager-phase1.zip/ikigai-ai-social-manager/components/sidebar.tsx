import Link from 'next/link';
import { Activity, CalendarDays, ChartNoAxesCombined, CheckCircle2, Compass, LayoutDashboard, PenLine, Settings2, Sparkles } from 'lucide-react';
const links = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { href: '/dashboard/research', label: 'Research lab', icon: Compass },
  { href: '/dashboard/content', label: 'Content studio', icon: PenLine },
  { href: '/dashboard/approvals', label: 'Approval center', icon: CheckCircle2 },
  { href: '/dashboard/calendar', label: 'Calendar', icon: CalendarDays },
  { href: '/dashboard/analytics', label: 'Analytics', icon: ChartNoAxesCombined },
  { href: '/dashboard/settings', label: 'Brand settings', icon: Settings2 },
];
export function Sidebar() { return <aside className="sidebar"><Link href="/dashboard" className="side-brand"><span className="brand-mark small">I</span><span><strong>IKIGAI</strong><small>AI SOCIAL MANAGER</small></span></Link><div className="workspace-label">WORKSPACE</div><nav>{links.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className="nav-link"><Icon size={17}/>{label}{label === 'Approval center' && <span className="nav-count">0</span>}</Link>)}</nav><div className="sidebar-bottom"><div className="ai-status"><span className="status-dot"/><span><b>AI team</b><small>Ready for your direction</small></span></div><form action="/auth/signout" method="post"><button className="signout-button">Sign out</button></form></div></aside>; }
