export const BRAND = {
  name: 'IKIGAI PROJECT', tagline: 'Discover what makes your life meaningful.',
  description: 'A thoughtful space for self-discovery, career exploration and meaningful work.',
  language: 'English', timezone: 'Europe/Bucharest',
  colors: ['#F5F0E8', '#E9DFD1', '#C9B8A3', '#A58E78', '#6F5B49', '#C6A878'],
  voice: ['intelligent', 'thoughtful', 'elegant', 'modern', 'warm', 'inspiring'],
  pillars: ['Self-discovery', 'Ikigai & meaning', 'Career exploration', 'Personal growth', 'Practical reflection'],
} as const;
export const PLATFORMS = [
  { id: 'instagram', label: 'Instagram', short: 'IG' }, { id: 'tiktok', label: 'TikTok', short: 'TT' },
  { id: 'facebook', label: 'Facebook', short: 'FB' }, { id: 'linkedin', label: 'LinkedIn', short: 'IN' },
  { id: 'youtube', label: 'YouTube', short: 'YT' },
] as const;
