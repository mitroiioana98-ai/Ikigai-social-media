export type ApprovalStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'scheduled' | 'published';
export type Platform = 'instagram' | 'tiktok' | 'facebook' | 'linkedin' | 'youtube';
export type ContentFormat = 'reel' | 'short' | 'carousel' | 'single_image' | 'story' | 'text_post' | 'long_video';
export type ContentPost = { id: string; title: string; caption: string | null; platform: Platform; format: ContentFormat; approval_status: ApprovalStatus; scheduled_at: string | null; created_at: string };
