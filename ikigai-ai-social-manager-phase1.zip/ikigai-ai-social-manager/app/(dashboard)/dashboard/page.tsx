import { ArrowUpRight, Clock3, FileText, Instagram, Plus, Sparkles, Target, TrendingUp } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import type { ContentPost } from '@/lib/types';
import { BRAND } from '@/lib/constants';

const demoPosts: ContentPost[] = [
  { id: 'demo-1', title: 'The problem isn’t you. It’s the path you were told to follow.', caption: 'A reflective Reel about career uncertainty.', platform: 'instagram', format: 'reel', approval_status: 'pending', scheduled_at: null, created_at: new Date().toISOString() },
  { id: 'demo-2', title: '5 questions to help you understand what matters', caption: 'A practical carousel for self-discovery.', platform: 'linkedin', format: 'carousel', approval_status: 'draft', scheduled_at: null, created_at: new Date().toISOString() },
  { id: 'demo-3', title: 'Your career is allowed to evolve.', caption: 'A short reflection about growth.', platform: 'tiktok', format: 'short', approval_status: 'approved', scheduled_at: null, created_at: new Date().toISOString() },
];

export default async function DashboardPage() {
  let posts = demoPosts; let connected = false; let userEmail = 'Preview workspace';
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (user) userEmail = user.email || 'Workspace owner';
    const { data } = await supabase.from('content_posts').select('id,title,caption,platform,format,approval_status,scheduled_at,created_at').order('created_at', { ascending: false }).limit(6);
    if (data) { posts = data as ContentPost[]; connected = true; }
  } catch { /* Preview mode until Supabase is configured. */ }
  const pending = posts.filter(p => p.approval_status === 'pending');
  return <div className="page-wrap"><header className="topbar"><div><p className="eyebrow">WEDNESDAY · YOUR CREATIVE WORKSPACE</p><h1>Good evening.</h1><p className="muted">A little clarity. A little progress. A more meaningful presence.</p></div><div className="topbar-right"><span className="avatar">I</span><span className="user-label">{userEmail}</span></div></header>
    <section className="welcome-panel"><div className="welcome-copy"><span className="pill"><Sparkles size={13}/> YOUR AI TEAM IS READY</span><h2>Make room for meaningful work.</h2><p>Your content operations, thoughtfully organised in one place.</p><a className="text-link" href="/dashboard/content">Open content studio <ArrowUpRight size={15}/></a></div><div className="welcome-orbit"><div className="orbit-ring ring-one"/><div className="orbit-ring ring-two"/><span>IK</span></div></section>
    <section className="metric-grid"><Metric icon={<FileText/>} label="Content pieces" value={String(posts.length).padStart(2,'0')} note="In your workspace"/><Metric icon={<Clock3/>} label="Awaiting approval" value={String(pending.length).padStart(2,'0')} note="Your review needed"/><Metric icon={<Target/>} label="Brand pillars" value="05" note="Defined & ready"/><Metric icon={<TrendingUp/>} label="Connected channels" value="00" note="Connect in next phase"/></section>
    <section className="content-grid"><div className="panel recent-panel"><div className="section-heading"><div><p className="eyebrow">YOUR PIPELINE</p><h3>Recent content</h3></div><a href="/dashboard/content" className="text-link">View all <ArrowUpRight size={14}/></a></div>{posts.length ? <div className="post-list">{posts.map(post => <article className="post-row" key={post.id}><div className="post-icon"><Instagram size={18}/></div><div className="post-info"><strong>{post.title}</strong><span>{post.platform} · {post.format.replace('_',' ')}</span></div><Status status={post.approval_status}/></article>)}</div> : <div className="empty-state">Your content pipeline is clear. Create your first idea to get started.</div>}</div>
      <div className="panel focus-panel"><p className="eyebrow">NEXT BEST ACTION</p><h3>Build your first content batch.</h3><p>Start with a small, consistent batch of thoughtful content across your chosen channels.</p><a href="/dashboard/content" className="primary-button inline-button"><Plus size={16}/> Create content</a><div className="focus-foot"><Sparkles size={15}/> Human approval is always required before publishing.</div></div></section>
    <footer className="page-footer"><span>{BRAND.name} · AI SOCIAL MANAGER</span><span className="footer-dot"/> <span>{connected ? 'Supabase connected' : 'Preview mode · connect Supabase to activate live data'}</span></footer>
  </div>;
}
function Metric({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: string; note: string }) { return <div className="metric-card"><div className="metric-top"><span>{label}</span><i>{icon}</i></div><strong>{value}</strong><small>{note}</small></div>; }
function Status({ status }: { status: string }) { return <span className={`status-badge status-${status}`}>{status}</span>; }
