import { signIn } from './actions';
export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return <main className="auth-shell"><section className="auth-card"><div className="brand-mark">I</div><p className="eyebrow">IKIGAI PROJECT</p><h1>Your social studio.</h1><p className="muted">Sign in to plan, create and approve your content.</p>
    {error && <p className="error-message">{error}</p>}
    <form action={signIn} className="auth-form"><label>Email<input name="email" type="email" autoComplete="email" required placeholder="you@example.com" /></label><label>Password<input name="password" type="password" autoComplete="current-password" required placeholder="Your password" /></label><button className="primary-button" type="submit">Sign in</button></form>
    <p className="fine-print">Access is invitation-only for the initial MVP. Create your first user in Supabase Authentication.</p></section></main>;
}
