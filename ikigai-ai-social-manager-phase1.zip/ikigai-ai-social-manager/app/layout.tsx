import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'IKIGAI AI Social Manager', description: 'Your thoughtful AI-powered social media studio.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
